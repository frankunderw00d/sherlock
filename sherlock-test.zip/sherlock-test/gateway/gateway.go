package main

import (
	"flag"
	"os"
	"os/signal"
	"sherlock"
	"sherlock/log"
	"sherlock/service/gateway"
)

type ()

const (
	ServiceName = "Gateway"
)

var (
	address = flag.String("address", "nats://127.0.0.1:9998", "")
	token   = flag.String("token", "9el5ydCrOC3pXVCmhFs0A4YCaobQe2dR", "")
)

var (
	httpGateway      gateway.Gateway
	webSocketGateway gateway.Gateway
)

func init() {
	flag.Parse()

	log.SetFormatter(log.NewStringFormatter([]string{ServiceName}))
	log.SetFilterLevel(log.LevelDebug)
}

func main() {
	// 1.网关初始化
	httpGateway = gateway.NewHTTPGateway(":8080")
	webSocketGateway = gateway.NewWebSocketGateway(":8081")

	// 2.初始化
	if err := sherlock.Init(ServiceName, *address, *token); err != nil {
		log.ErrorF("sherlock initialize error : %s", err.Error())
		return
	}

	// 3.运行
	if err := sherlock.Run(httpGateway, webSocketGateway); err != nil {
		log.ErrorF("sherlock run error : %s", err.Error())
		return
	}

	// 4.监听信号
	MonitorSignal()
}

// 监听系统信号
func MonitorSignal() {
	signalChannel := make(chan os.Signal, 0)
	signal.Notify(signalChannel, os.Interrupt)
	select {
	case s := <-signalChannel:
		{
			log.InfoF("Receive interrupt signal : %s", s.String())
			if err := httpGateway.Close(); err != nil {
				log.ErrorF("HTTP gateway close error : %s", err.Error())
			}
			if err := webSocketGateway.Close(); err != nil {
				log.ErrorF("WebSocket gateway close error : %s", err.Error())
			}
			if err := sherlock.Close(); err != nil {
				log.ErrorF("Sherlock close %s service error : %s", ServiceName, err.Error())
			}
		}
	}
}
