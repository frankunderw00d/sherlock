package route

import (
	"github.com/nats-io/nats.go"
	"sherlock/log"
)

type ()

const ()

var ()

func init() {}

func Register(message *nats.Msg) {
	ErrorHandler("Reply to register request", message.Respond([]byte("Register success")))
}

func Login(message *nats.Msg) {
	ErrorHandler("Reply to login request", message.Respond([]byte("login success")))
}

func UpdatePassword(message *nats.Msg) {
	ErrorHandler("Reply to update password request", message.Respond([]byte("update password success")))
}

func UpdateUserInfo(message *nats.Msg) {
	ErrorHandler("Reply to update user info request", message.Respond([]byte("update user info success")))
}

func ErrorHandler(errorInfo string, err error) {
	if err == nil {
		return
	}
	log.ErrorF("%s : %s", errorInfo, err.Error())
}
