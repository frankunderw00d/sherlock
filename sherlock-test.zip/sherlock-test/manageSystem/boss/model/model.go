package model

import (
	"time"
)

type (
	Boss struct {
		ID        uint      `gorm:"primarykey"`
		CreatedAt time.Time `gorm:"autoCreateTime:milli;not null"`
		UpdatedAt time.Time `gorm:"autoUpdateTime:milli;not null"`
		Account   string    `gorm:"unique;not null"`
		Password  string    `gorm:"not null"`
		Name      string    `gorm:"name"`
		Age       string    `gorm:"age"`
		Sex       bool      `gorm:"sex"`
	}
)

func (b *Boss) TableName() string {
	return "static_boss"
}
