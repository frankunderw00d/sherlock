package main

import (
	"flag"
	"os"
	"os/signal"
	"sherlock"
	"sherlock-test/manageSystem/boss/middleware"
	"sherlock-test/manageSystem/boss/model"
	"sherlock-test/manageSystem/boss/route"
	"sherlock/database/mysql"
	"sherlock/log"
	"sherlock/service/manageSystem"
)

type ()

const (
	ServiceName    = "Boss"
	ServiceVersion = "v1.0.0"
)

var (
	address = flag.String("address", "nats://127.0.0.1:9998", "")
	token   = flag.String("token", "9el5ydCrOC3pXVCmhFs0A4YCaobQe2dR", "")
)

var (
	boosManageSystem manageSystem.ManageSystem
)

func init() {
	flag.Parse()

	log.SetFormatter(log.NewStringFormatter([]string{ServiceName}))
	log.SetFilterLevel(log.LevelDebug)

	boosManageSystem = manageSystem.NewManageSystem(ServiceName, ServiceVersion)

	// 初始化 MySQL
	if err := mysql.InitializeMySQL(
		"frank",
		"frank123",
		"localhost",
		"7000",
		"jarvis",
	); err != nil {
		log.FatalF("Initialize MySQL error : %s", err.Error())
	}

	// 注册数据模型
	if err := RegisterModel(); err != nil {
		log.FatalF("Register model error : %s", err.Error())
	}
}

func main() {
	// 1.加入全局中间件
	if err := boosManageSystem.UseMiddleware(middleware.RequestPrint); err != nil {
		log.ErrorF("Use global middleware error : %s", err.Error())
		return
	}

	// 2.订阅路径
	if err := RegisterRoute(); err != nil {
		log.ErrorF("Register route [Login] error : %s", err.Error())
		return
	}

	// 3.初始化
	if err := sherlock.Init(ServiceName, *address, *token); err != nil {
		log.ErrorF("sherlock initialize error : %s", err.Error())
		return
	}

	// 4.运行
	if err := sherlock.Run(boosManageSystem); err != nil {
		log.ErrorF("sherlock run error : %s", err.Error())
		return
	}

	// 5.监听信号
	MonitorSignal()
}

// 注册模型
func RegisterModel() error {
	if err := mysql.RegisterTable(new(model.Boss)); err != nil {
		return err
	}

	return nil
}

// 注册路由
func RegisterRoute() error {
	// 1.注册
	if err := boosManageSystem.RegisterRoute("Register", route.Register); err != nil {
		return err
	}

	// 2.登录
	if err := boosManageSystem.RegisterRoute("Login", route.Login); err != nil {
		return err
	}

	// 3.修改密码
	if err := boosManageSystem.RegisterRoute("UpdatePassword", route.UpdatePassword); err != nil {
		return err
	}

	// 4.修改用户信息
	if err := boosManageSystem.RegisterRoute("UpdateUserInfo", route.UpdateUserInfo); err != nil {
		return err
	}

	return nil
}

// 监听系统信号
func MonitorSignal() {
	signalChannel := make(chan os.Signal, 0)
	signal.Notify(signalChannel, os.Interrupt)
	select {
	case s := <-signalChannel:
		{
			log.InfoF("Receive interrupt signal : %s", s.String())
			boosManageSystem.Close()
			if err := sherlock.Close(); err != nil {
				log.ErrorF("Sherlock close %s service error : %s", ServiceName, err.Error())
			}
		}
	}
}
