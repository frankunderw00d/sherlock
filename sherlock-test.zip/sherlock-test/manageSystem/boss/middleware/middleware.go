package middleware

import (
	"github.com/nats-io/nats.go"
	"sherlock/log"
)

type ()

const ()

var ()

func init() {}

func RequestPrint(message *nats.Msg) bool {
	log.InfoF("[%s]-[%s] : %s", message.Sub.Subject, message.Sub.Queue, string(message.Data))
	return true
}
