package main

import (
	"encoding/json"
	"flag"
	"github.com/nats-io/nats.go"
	"os"
	"os/signal"
	"sherlock"
	"sherlock/log"
	"sherlock/service/lobby"
)

type (
	SlotRoom struct {
		PlatformID string `json:"platform_id"` // 业主 ID
		GameID     string `json:"game_id"`     // 游戏 ID
		Name       string `json:"name"`        // 房间名称
		ID         string `json:"id"`          // 房间ID
		Threshold  uint64 `json:"threshold"`   // 门槛
		Multiple   uint   `json:"multiple"`    // 倍率
		Commission uint   `json:"commission"`  // 抽水比例值
	}

	Slot struct {
		lobby.Lobby
		Rooms []*SlotRoom // 房间
	}
)

const (
	ServiceName    = "Slot"
	ServiceVersion = "v1.0.0"
)

var (
	address = flag.String("address", "nats://127.0.0.1:9998", "")
	token   = flag.String("token", "9el5ydCrOC3pXVCmhFs0A4YCaobQe2dR", "")
)

var (
	slot *Slot
)

func init() {
	simulationData()

	flag.Parse()

	log.SetFormatter(log.NewStringFormatter([]string{ServiceName}))
	log.SetFilterLevel(log.LevelDebug)

	slot = &Slot{Lobby: lobby.NewLobby(
		"PIDPIDPIDPIDPIDPIDPIDPIDPIDPID01",
		"GIDGIDGIDGIDGIDGIDGIDGIDGIDGID01",
		ServiceName,
	),
		Rooms: LoadRoom(),
	}
}

func main() {
	// 1.加入全局中间件
	if err := slot.UseMiddleware(GlobalMiddlewareOne, GlobalMiddlewareTwo); err != nil {
		log.ErrorF("Use global middleware error : %s", err.Error())
		return
	}

	// 2.订阅路径
	if err := RegisterRoute(); err != nil {
		log.ErrorF("Register route [Login] error : %s", err.Error())
		return
	}

	// 3.初始化
	if err := sherlock.Init(ServiceName, *address, *token); err != nil {
		log.ErrorF("sherlock initialize error : %s", err.Error())
		return
	}

	// 4.运行
	if err := sherlock.Run(slot); err != nil {
		log.ErrorF("sherlock run error : %s", err.Error())
		return
	}

	// 5.监听信号
	MonitorSignal()
}

// 监听系统信号
func MonitorSignal() {
	signalChannel := make(chan os.Signal, 0)
	signal.Notify(signalChannel, os.Interrupt)
	select {
	case s := <-signalChannel:
		{
			log.InfoF("Receive interrupt signal : %s", s.String())
			slot.Close()
			if err := sherlock.Close(); err != nil {
				log.ErrorF("Sherlock close %s service error : %s", ServiceName, err.Error())
			}
		}
	}
}

func (s *Slot) EnterHandler(message *nats.Msg) {
	log.InfoF("Enter handler receive message : %s", string(message.Data))

	if message.Reply != "" {
		if err := message.Respond([]byte("Enter lobby success")); err != nil {
			log.ErrorF("Reply to [%s] error : %s", message.Reply, err.Error())
		}
	}
}

func (s *Slot) RoomInfoListHandler(message *nats.Msg) {
	log.InfoF("Room information list handler receive message : %s", string(message.Data))

	if data, err := json.Marshal(&(s.Rooms)); err != nil {
		log.ErrorF("Marshal slot rooms error : %s", err.Error())
		if err := message.Respond([]byte(err.Error())); err != nil {
			log.ErrorF("Reply to [%s] error : %s", message.Reply, err.Error())
		}
		return
	} else {
		log.InfoF("Rooms info list : %s", string(data))
	}

	if message.Reply != "" {
		if err := message.Respond([]byte("get room success")); err != nil {
			log.ErrorF("Reply to [%s] error : %s", message.Reply, err.Error())
		}
	}
}

func (s *Slot) EnterRoomHandler(message *nats.Msg) {
	log.InfoF("Enter room handler receive message : %s", string(message.Data))

	if message.Reply != "" {
		if err := message.Respond([]byte("Enter room success")); err != nil {
			log.ErrorF("Reply to [%s] error : %s", message.Reply, err.Error())
		}
	}
}

func (s *Slot) ExitHandler(message *nats.Msg) {
	log.InfoF("Exit handler receive message : %s", string(message.Data))

	if message.Reply != "" {
		if err := message.Respond([]byte("Exit from slot lobby success")); err != nil {
			log.ErrorF("Reply to [%s] error : %s", message.Reply, err.Error())
		}
	}
}

func Middleware(message *nats.Msg) bool {
	log.InfoF("Middleware receive message : %+v", string(message.Data))
	return true
}

func GlobalMiddlewareOne(message *nats.Msg) bool {
	log.InfoF("Global middleware one receive message : %+v", string(message.Data))
	return true
}

func GlobalMiddlewareTwo(message *nats.Msg) bool {
	log.InfoF("Global middleware two receive message : %+v", string(message.Data))
	return true
}

// 加载房间
func LoadRoom() []*SlotRoom {
	rooms := make([]*SlotRoom, 0)

	rooms = append(rooms, &SlotRoom{
		PlatformID: "PIDPIDPIDPIDPIDPIDPIDPIDPIDPID01",
		GameID:     "GIDGIDGIDGIDGIDGIDGIDGIDGIDGID01",
		Name:       "新手房",
		ID:         "RIDRIDRIDRIDRIDRIDRIDRIDRIDRID01",
		Threshold:  10,
		Multiple:   1,
		Commission: 5,
	})

	rooms = append(rooms, &SlotRoom{
		PlatformID: "PIDPIDPIDPIDPIDPIDPIDPIDPIDPID01",
		GameID:     "GIDGIDGIDGIDGIDGIDGIDGIDGIDGID01",
		Name:       "初级房",
		ID:         "RIDRIDRIDRIDRIDRIDRIDRIDRIDRID02",
		Threshold:  100,
		Multiple:   10,
		Commission: 5,
	})

	rooms = append(rooms, &SlotRoom{
		PlatformID: "PIDPIDPIDPIDPIDPIDPIDPIDPIDPID01",
		GameID:     "GIDGIDGIDGIDGIDGIDGIDGIDGIDGID01",
		Name:       "中级房",
		ID:         "RIDRIDRIDRIDRIDRIDRIDRIDRIDRID03",
		Threshold:  100,
		Multiple:   50,
		Commission: 5,
	})

	rooms = append(rooms, &SlotRoom{
		PlatformID: "PIDPIDPIDPIDPIDPIDPIDPIDPIDPID01",
		GameID:     "GIDGIDGIDGIDGIDGIDGIDGIDGIDGID01",
		Name:       "高级房",
		ID:         "RIDRIDRIDRIDRIDRIDRIDRIDRIDRID04",
		Threshold:  1000,
		Multiple:   150,
		Commission: 5,
	})

	return rooms
}

// 注册路由
func RegisterRoute() error {
	if err := slot.RegisterRoute("EnterLobby", slot.EnterHandler, Middleware); err != nil {
		return err
	}

	if err := slot.RegisterRoute("RoomInfoList", slot.RoomInfoListHandler, Middleware); err != nil {
		return err
	}

	if err := slot.RegisterRoute("EnterRoom", slot.EnterRoomHandler, Middleware); err != nil {
		return err
	}

	if err := slot.RegisterRoute("ExitLobby", slot.ExitHandler, Middleware); err != nil {
		return err
	}

	return nil
}

func (sr *SlotRoom) RoomID() string {
	return sr.ID
}

func (sr *SlotRoom) String() string {
	if data, err := json.Marshal(sr); err != nil {
		return ""
	} else {
		return string(data)
	}
}

func simulationData() {
	type Message struct {
		Subject string `json:"subject"`
		Data    []byte `json:"data"`
	}

	a := &Message{
		Subject: "Lobby.PIDPIDPIDPIDPIDPIDPIDPIDPIDPID01.GIDGIDGIDGIDGIDGIDGIDGIDGIDGID01.EnterLobby",
		Data:    []byte("Frank want to enter slot lobby"),
	}
	if data, err := json.Marshal(a); err != nil {
		log.ErrorF("marshal message error : %s", err.Error())
	} else {
		log.InfoLn(string(data))
	}

	b := &Message{
		Subject: "Lobby.PIDPIDPIDPIDPIDPIDPIDPIDPIDPID01.GIDGIDGIDGIDGIDGIDGIDGIDGIDGID01.RoomInfoList",
		Data:    []byte("Frank want to get room info list of slot lobby"),
	}
	if data, err := json.Marshal(b); err != nil {
		log.ErrorF("marshal message error : %s", err.Error())
	} else {
		log.InfoLn(string(data))
	}

	c := &Message{
		Subject: "Lobby.PIDPIDPIDPIDPIDPIDPIDPIDPIDPID01.GIDGIDGIDGIDGIDGIDGIDGIDGIDGID01.EnterRoom",
		Data:    []byte("Frank want to enter the room of slot lobby"),
	}
	if data, err := json.Marshal(c); err != nil {
		log.ErrorF("marshal message error : %s", err.Error())
	} else {
		log.InfoLn(string(data))
	}

	d := &Message{
		Subject: "Lobby.PIDPIDPIDPIDPIDPIDPIDPIDPIDPID01.GIDGIDGIDGIDGIDGIDGIDGIDGIDGID01.ExitLobby",
		Data:    []byte("Frank want to exit the slot lobby"),
	}
	if data, err := json.Marshal(d); err != nil {
		log.ErrorF("marshal message error : %s", err.Error())
	} else {
		log.InfoLn(string(data))
	}
}
