package main

import (
	"encoding/json"
	"io/ioutil"
	"log"
	"net/http"
)

type ()

const ()

var ()

func init() {}

func main() {
	http.HandleFunc("/code", func(writer http.ResponseWriter, request *http.Request) {
		data, err := ioutil.ReadFile("index.html")
		if err != nil {
			_, _ = writer.Write([]byte(err.Error()))
			return
		}

		_, _ = writer.Write(data)
	})

	http.HandleFunc("/encode", func(writer http.ResponseWriter, request *http.Request) {
		data, err := ioutil.ReadAll(request.Body)
		if err != nil {
			_, _ = writer.Write([]byte(err.Error()))
			return
		}

		log.Printf("data : %s", string(data))

		type Message struct {
			Subject string `json:"subject"`
			Data    string `json:"data"`
		}

		type Message2 struct {
			Subject string `json:"subject"`
			Data    []byte `json:"data"`
		}

		m := &Message{}
		if err := json.Unmarshal(data, m); err != nil {
			_, _ = writer.Write([]byte(err.Error()))
			return
		}

		log.Printf("%+v", m)

		if data, err := json.Marshal(&Message2{
			Subject: m.Subject,
			Data:    []byte(m.Data),
		}); err != nil {
			_, _ = writer.Write([]byte(err.Error()))
		} else {
			_, _ = writer.Write(data)
		}

	})

	if err := http.ListenAndServe(":10003", nil); err != nil {
		log.Println(err.Error())
	}
}
