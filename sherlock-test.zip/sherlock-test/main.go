package main

import (
	"encoding/base64"
	"encoding/json"
	"log"
)

type ()

const ()

var ()

func init() {}

func main() {
	a := []byte("a")
	if d, err := json.Marshal(&a); err != nil {
		log.Println(err.Error())
		return
	} else {
		log.Println(d)
		log.Println(string(d))
	}

	dst := make([]byte, 1024)
	base64.StdEncoding.Encode(dst, a)
	i := 0
	for ;i<len(dst);i++{
		if dst[i] == 0 {
			break
		}
		log.Println(dst[i])
	}
	log.Println(i)
	log.Println(dst[:i])
	log.Printf("[%s]", dst[:i])

	log.Printf("[%s]", string([]byte{0}))
}
